#!/bin/bash

java  -Djava.ext.dirs=./lib -jar ./lib/DB4JavaTools-2.0.jar > result.txt
