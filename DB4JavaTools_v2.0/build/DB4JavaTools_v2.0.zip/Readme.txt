提供的变量
表名：__TABLE_NAME , eg: t_user, T_USER, tUser

字段列表： __COLUMN_LIST, __PID_LIST
字段属性： __COLUMN_NAME, __COLUMN_TYPE, __IS_PID
		
方法
大写：StringUtil.toUpper 
小写：StringUtil.toLower
去掉下划线：StringUtil.noUnderLine
首字母大写：StringUtil.firstCharToUpper
首字母小写：StringUtil.firstCharToLower